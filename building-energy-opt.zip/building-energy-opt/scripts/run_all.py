"""End-to-end pipeline: analysis -> forecasting -> anomaly flagging -> pre-cooling optimization.

Usage:  python scripts/run_all.py [--trials 40]
Outputs go to results/ (CSV/JSON tables) and results/figures/ (PNG).
"""
import argparse
import json
import sys
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import shap

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
from energyopt import analysis, forecast, optimize  # noqa: E402
from energyopt.config import BUILDINGS, FIGURES, OPT_BUILDING, RESULTS, TRAIN_END  # noqa: E402
from energyopt.data import load_long, load_metadata  # noqa: E402
from energyopt.features import FEATURES, build_features  # noqa: E402
from energyopt.metrics import all_metrics  # noqa: E402

plt.rcParams.update({"figure.dpi": 130, "axes.spines.top": False, "axes.spines.right": False,
                     "axes.grid": True, "grid.alpha": 0.25, "font.size": 9})
C = {"actual": "#222222", "xgb": "#1f6fb2", "towt": "#e08a1e", "naive": "#9a9a9a",
     "t24": "#9a9a9a", "t26": "#e08a1e", "lp_forecast": "#1f6fb2", "lp_oracle": "#2e9e5b"}


def short(b):
    return b.replace("Fox_", "").replace("_", " ")


# ------------------------------------------------------------------ 1. analysis
def run_analysis(long, meta):
    rows, fits = [], {}
    fig, axes = plt.subplots(1, len(BUILDINGS), figsize=(15, 3))
    for ax, b in zip(axes, BUILDINGS):
        g = long[(long.building == b) & (long.timestamp <= TRAIN_END)].set_index("timestamp")
        d = g[["airTemperature", "load_kw"]].resample("D").mean()
        f = analysis.fit_3p_cooling(d["airTemperature"], d["load_kw"])
        fits[b] = f
        rows.append({"building": b, "use": meta.loc[b, "primaryspaceusage"], "sqm": meta.loc[b, "sqm"],
                     "mean_kw": g["load_kw"].mean(), "base_kw": f["b0"], "slope_kw_per_K": f["b1"],
                     "balance_point_C": f["Tb"], "r2": f["r2"], "cvrmse_daily": f["cvrmse"],
                     "weather_driven_share": f["weather_share"],
                     "eui_kwh_m2_yr": g["load_kw"].sum() / meta.loc[b, "sqm"]})
        ax.scatter(d["airTemperature"], d["load_kw"], s=5, alpha=0.5, color=C["naive"])
        xs = np.linspace(d["airTemperature"].min(), d["airTemperature"].max(), 100)
        ax.plot(xs, f["b0"] + f["b1"] * np.clip(xs - f["Tb"], 0, None), color=C["xgb"], lw=2)
        ax.set_title(f"{short(b)}\nTb={f['Tb']:.1f}°C, R²={f['r2']:.2f}")
        ax.set_xlabel("daily mean outdoor temp (°C)")
    axes[0].set_ylabel("daily mean load (kW)")
    fig.tight_layout()
    fig.savefig(FIGURES / "01_changepoint_models.png")
    plt.close(fig)

    fig, axes = plt.subplots(1, len(BUILDINGS), figsize=(15, 2.8))
    for ax, b in zip(axes, BUILDINGS):
        g = long[(long.building == b) & (long.timestamp <= TRAIN_END)]
        piv = g.pivot_table(index=g.timestamp.dt.dayofweek, columns=g.timestamp.dt.hour, values="load_kw")
        im = ax.imshow(piv, aspect="auto", cmap="viridis")
        ax.set_yticks(range(7), ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"])
        ax.set_xticks([0, 6, 12, 18, 23])
        ax.set_xlabel("hour")
        ax.set_title(short(b))
        ax.grid(False)
        fig.colorbar(im, ax=ax, fraction=0.046, label="kW")
    fig.tight_layout()
    fig.savefig(FIGURES / "02_load_profiles_heatmap.png")
    plt.close(fig)

    tab = pd.DataFrame(rows)
    tab.to_csv(RESULTS / "analysis_changepoint.csv", index=False)
    return tab, fits


# ------------------------------------------------------------------ 2. forecasting
def run_forecast(long, n_trials):
    rows, preds, models = [], [], {}
    for b in BUILDINGS:
        f = build_features(long[long.building == b])
        train, test = forecast.split(f)
        p_naive = forecast.naive_seasonal(test)
        p_towt = forecast.towt_fit_predict(train, test)
        params, n_trees = forecast.tune_xgb(train, n_trials=n_trials)
        m = forecast.fit_xgb(train, params, n_trees)
        p_xgb = m.predict(test[FEATURES])
        models[b] = (m, test)
        for name, p in [("naive_lastweek", p_naive), ("towt_regression", p_towt), ("xgboost", p_xgb)]:
            rows.append({"building": b, "model": name, "n_test_hours": len(test),
                         **all_metrics(test["load_kw"], p)})
        preds.append(pd.DataFrame({"timestamp": test["timestamp"].values, "building": b,
                                   "actual": test["load_kw"].values, "naive": p_naive,
                                   "towt": p_towt, "xgb": p_xgb}))
        with open(RESULTS / f"xgb_params_{b}.json", "w") as fh:
            json.dump({"params": params, "n_trees": n_trees}, fh, indent=1)
        print(f"  {b}: xgb CV(RMSE) {rows[-1]['cvrmse']:.1f}%  NMBE {rows[-1]['nmbe']:+.2f}%  "
              f"(TOWT {rows[-2]['cvrmse']:.1f}%, naive {rows[-3]['cvrmse']:.1f}%)")
    met = pd.DataFrame(rows)
    met.to_csv(RESULTS / "forecast_metrics.csv", index=False)
    pred = pd.concat(preds)
    pred.to_parquet(RESULTS / "forecast_predictions_2017.parquet", index=False)

    w = pred[(pred.building == OPT_BUILDING) & (pred.timestamp >= "2017-07-10") & (pred.timestamp < "2017-07-17")]
    fig, ax = plt.subplots(figsize=(11, 3.2))
    ax.plot(w.timestamp, w.actual, color=C["actual"], lw=1.6, label="actual")
    ax.plot(w.timestamp, w.xgb, color=C["xgb"], lw=1.3, label="XGBoost")
    ax.plot(w.timestamp, w.towt, color=C["towt"], lw=1, ls="--", label="TOWT regression")
    ax.plot(w.timestamp, w.naive, color=C["naive"], lw=1, ls=":", label="same hour last week")
    ax.set_ylabel("kW")
    ax.set_title(f"{short(OPT_BUILDING)}: day-ahead forecasts, 10-16 Jul 2017 (test period)")
    ax.legend(ncol=4, loc="upper left", frameon=False)
    fig.tight_layout()
    fig.savefig(FIGURES / "03_forecast_week.png")
    plt.close(fig)

    piv = met.pivot(index="building", columns="model", values="cvrmse").loc[BUILDINGS]
    fig, ax = plt.subplots(figsize=(8, 3))
    x = np.arange(len(piv))
    for i, (col, lab, c) in enumerate([("naive_lastweek", "same hour last week", C["naive"]),
                                        ("towt_regression", "TOWT regression", C["towt"]),
                                        ("xgboost", "XGBoost", C["xgb"])]):
        ax.bar(x + (i - 1) * 0.27, piv[col], 0.27, label=lab, color=c)
    ax.axhline(30, color="#b23b3b", lw=1, ls="--")
    ax.text(len(piv) - 0.5, 30.5, "ASHRAE G14 hourly limit (30%)", ha="right", va="bottom",
            color="#b23b3b", fontsize=8)
    ax.set_xticks(x, [short(b) for b in piv.index])
    ax.set_ylabel("CV(RMSE) on 2017, %")
    ax.legend(frameon=False, fontsize=8)
    fig.tight_layout()
    fig.savefig(FIGURES / "04_forecast_cvrmse.png")
    plt.close(fig)

    m, test = models[OPT_BUILDING]
    sample = test[FEATURES].sample(min(3000, len(test)), random_state=0)
    sv = shap.TreeExplainer(m).shap_values(sample)
    plt.figure()
    shap.summary_plot(sv, sample, show=False, max_display=12, plot_size=(7, 4.2))
    plt.title(f"SHAP: drivers of hourly load, {short(OPT_BUILDING)}")
    plt.tight_layout()
    plt.savefig(FIGURES / "05_shap_office.png")
    plt.close("all")
    imp = pd.Series(np.abs(sv).mean(0), index=FEATURES).sort_values(ascending=False)
    imp.to_csv(RESULTS / "shap_importance_office.csv", header=["mean_abs_shap_kw"])
    return met, pred, imp


# ------------------------------------------------------------------ 3. anomalies
def run_anomalies(pred):
    out = []
    for b in BUILDINGS:
        p = pred[pred.building == b]
        d = analysis.flag_anomalous_days(p.timestamp, p.actual, p.xgb)
        d["building"] = b
        out.append(d.rename_axis("date").reset_index())
    an = pd.concat(out)
    an.to_csv(RESULTS / "anomaly_days_2017.csv", index=False)

    show = an.groupby("building").anomaly.sum().idxmax()  # building with the most flagged days
    d = an[an.building == show]
    flag = d[d.anomaly]
    fig, ax = plt.subplots(figsize=(11, 3))
    ax.plot(d["date"], d["resid_kwh"], color=C["naive"], lw=0.8)
    ax.scatter(flag["date"], flag["resid_kwh"], color="#b23b3b", zorder=3, s=18,
               label=f"flagged: {len(flag)} days (robust z > 3.5)")
    ax.axhline(0, color="black", lw=0.6)
    ax.set_ylabel("actual − expected (kWh/day)")
    ax.set_title(f"{short(show)}: daily energy not explained by weather and schedule, 2017")
    ax.legend(frameon=False)
    fig.tight_layout()
    fig.savefig(FIGURES / "06_anomaly_days.png")
    plt.close(fig)
    return an


# ------------------------------------------------------------------ 4. optimization
NAMES = {"t24": "Thermostat, fixed 24 °C", "t26": "Thermostat, 26 °C (band ceiling)",
         "lp_forecast": "LP pre-cooling, XGBoost forecast", "lp_oracle": "LP pre-cooling, perfect foresight"}


def build_inputs(long, pred, fit, start="2017-06-01", end="2017-09-30 23:00"):
    """Hourly outdoor temp and non-cooling electric load (true and forecast) for the summer."""
    g = long[long.building == OPT_BUILDING].set_index("timestamp").sort_index().loc[start:end]
    p = pred[pred.building == OPT_BUILDING].set_index("timestamp")["xgb"].reindex(g.index)
    L_true = g["load_kw"].interpolate(limit=6).ffill()
    L_fc = p.fillna(L_true.shift(24)).ffill()
    tout = g["airTemperature"].to_numpy()
    cool_est = fit["b1"] * np.clip(tout - fit["Tb"], 0, None)

    def noncool(L):
        L = L.to_numpy()
        return np.clip(L - cool_est, 0.3 * L, None)

    return pd.DatetimeIndex(g.index), tout, noncool(L_true), noncool(L_fc)


def simulate(ts, tout, nc_true, nc_fc, zone, tariff, G_scale, mode):
    """Run one control strategy day by day over the period, carrying zone state forward."""
    G_true, G_fc = G_scale * nc_true, G_scale * nc_fc
    lo, hi, occ = optimize.comfort_bounds(ts)
    Q_all, T_all, T0 = np.zeros(len(ts)), np.zeros(len(ts) + 1), 26.0
    T_all[0] = T0
    for _, idx in pd.Series(np.arange(len(ts)), index=ts).groupby(ts.floor("D")):
        i = idx.to_numpy()
        if mode in ("t24", "t26"):
            # setback 29 degC overnight; 2 h optimal-start so the zone is at setpoint by 07:00
            h, wd = ts[i].hour, ts[i].dayofweek < 5
            on_sched = np.asarray(wd & (h >= 5) & (h < 19))
            sp = np.where(on_sched, 24.0 if mode == "t24" else 26.0, 29.0)
            Q, T = optimize.thermostat(zone, tout[i], G_true[i], T0, sp)
        else:
            use_fc = mode == "lp_forecast"
            Qc = optimize.plan_day(zone, tariff, ts[i], tout[i], (G_fc if use_fc else G_true)[i],
                                   (nc_fc if use_fc else nc_true)[i], T0, lo[i], hi[i])
            Q, T = optimize.execute(zone, tout[i], G_true[i], Qc, T0, lo[i], hi[i])
        Q_all[i], T_all[i + 1], T0 = Q, T[1:], T[-1]
    return Q_all, T_all, lo, hi, occ


def run_optimization(long, pred, fits):
    fit = fits[OPT_BUILDING]
    tariff = optimize.Tariff()
    ts, tout, nc_true, nc_fc = build_inputs(long, pred, fit)
    UA = fit["b1"] * 3.0
    G_mean = UA * (24.0 - fit["Tb"])
    G_scale = G_mean / nc_true.mean()

    # capacity: 1.3 x the steady-state design load (hottest hour, zone held at 24 degC)
    Q_max = 1.3 * float(np.max(UA * (tout - 24.0) + G_scale * nc_true))
    params = {"UA_kW_per_K": UA, "balance_point_C": fit["Tb"], "G_mean_kWth": G_mean, "Q_max_kWth": Q_max,
              "cop_ref_at_35C": 3.0, "period": "2017-06-01..2017-09-30", "tariff": tariff.__dict__}
    print("  zone:", {k: round(v, 2) if isinstance(v, float) else v for k, v in params.items()})

    results, runs = [], {}
    for tau in (5, 10, 20):
        zone = optimize.Zone(UA=UA, tau_h=tau, Q_max=Q_max)
        for mode in NAMES:
            Q, T, lo, hi, occ = simulate(ts, tout, nc_true, nc_fc, zone, tariff, G_scale, mode)
            r = optimize.summarise(NAMES[mode], ts, tout, Q, T, nc_true, zone, tariff, occ, lo, hi)
            r.update({"tau_h": tau, "mode": mode})
            results.append(r)
            runs[(tau, mode)] = (Q, T)
        print(f"  tau={tau}h done")
    res = pd.DataFrame(results)
    cols = ("total_cost", "energy_cost", "demand_cost", "mean_monthly_onpeak_peak_kw",
            "hvac_kwh", "hvac_onpeak_kwh", "building_kwh")
    for ref in ("t24", "t26"):
        base = res[res["mode"] == ref].set_index("tau_h")
        for col in cols:
            res[f"{col}_vs_{ref}_pct"] = 100 * (res[col] / res["tau_h"].map(base[col]) - 1)
    res.to_csv(RESULTS / "optimization_results.csv", index=False)
    with open(RESULTS / "optimization_zone_params.json", "w") as fh:
        json.dump(params, fh, indent=1, default=str)

    # example day: hottest weekday, tau = 10 h
    zone = optimize.Zone(UA=UA, tau_h=10, Q_max=Q_max)
    s = pd.Series(tout, index=ts)
    day = s[s.index.dayofweek < 5].resample("D").max().dropna().idxmax()
    i = np.where(ts.floor("D") == day)[0]
    hrs = np.asarray(ts[i].hour)
    lo, hi, _ = optimize.comfort_bounds(ts[i])
    on = tariff.is_on_peak(ts[i])
    fig, (a1, a2) = plt.subplots(2, 1, figsize=(9, 5.6), sharex=True)
    for ax in (a1, a2):
        ax.axvspan(hrs[on].min(), hrs[on].max() + 1, color="#b23b3b", alpha=0.07, lw=0)
    a1.fill_between(np.r_[hrs, 24], np.r_[lo, lo[-1]], np.r_[hi, hi[-1]], step="post",
                    color="#2e9e5b", alpha=0.10, label="comfort band")
    for mode in ("t24", "t26", "lp_forecast"):
        Q, T = runs[(10, mode)]
        a1.plot(np.r_[hrs, 24], np.r_[T[i[0]], T[i + 1]], color=C[mode], lw=1.8, label=NAMES[mode])
        a2.step(np.r_[hrs, 24], np.r_[nc_true[i] + Q[i] / zone.cop(tout[i]), np.nan], where="post",
                color=C[mode], lw=1.8)
    a1.set_ylabel("zone temp (°C)")
    a1.set_ylim(17, 30)
    a1.legend(frameon=False, fontsize=8, loc="lower left")
    a1b = a1.twinx()
    a1b.plot(hrs + 0.5, tout[i], color="#777", lw=1, ls=":")
    a1b.set_ylabel("outdoor temp (°C, dotted)")
    a1b.grid(False)
    a1b.spines["right"].set_visible(True)
    a2.set_ylabel("building power (kW)")
    a2.set_xlabel(f"hour of {day:%a %d %b %Y}   (shaded = on-peak price period)")
    a2.set_xticks(range(0, 25, 3))
    a1.set_title(f"Hottest weekday of summer 2017 (max {tout[i].max():.1f} °C), tau = 10 h")
    fig.tight_layout()
    fig.savefig(FIGURES / "07_precooling_hot_day.png")
    plt.close(fig)
    return res, params


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--trials", type=int, default=40)
    args = ap.parse_args()
    long, meta = load_long(), load_metadata()
    print("1/4 analysis")
    cp_tab, fits = run_analysis(long, meta)
    print("2/4 forecasting")
    met, pred, imp = run_forecast(long, args.trials)
    print("3/4 anomalies")
    an = run_anomalies(pred)
    print("4/4 optimization")
    res, _ = run_optimization(long, pred, fits)

    x = met[met.model == "xgboost"].set_index("building")
    t = met[met.model == "towt_regression"].set_index("building")
    n = met[met.model == "naive_lastweek"].set_index("building")
    keys = ("total_cost", "energy_cost", "demand_cost", "mean_monthly_onpeak_peak_kw",
            "hvac_kwh", "hvac_onpeak_kwh", "building_kwh")
    lp = res[(res["mode"] == "lp_forecast") & (res.tau_h == 10)].iloc[0]
    summary = {
        "xgb_cvrmse_mean": x.cvrmse.mean(), "xgb_cvrmse_range": [x.cvrmse.min(), x.cvrmse.max()],
        "xgb_nmbe_abs_max": x.nmbe.abs().max(),
        "towt_cvrmse_mean": t.cvrmse.mean(), "naive_cvrmse_mean": n.cvrmse.mean(),
        "xgb_vs_naive_cvrmse_reduction_pct": 100 * (1 - x.cvrmse.mean() / n.cvrmse.mean()),
        "xgb_vs_towt_cvrmse_reduction_pct": 100 * (1 - x.cvrmse.mean() / t.cvrmse.mean()),
        "all_within_g14": bool(((x.cvrmse <= 30) & (x.nmbe.abs() <= 10)).all()),
        "weather_share_by_building": cp_tab.set_index("building").weather_driven_share.round(3).to_dict(),
        "anomaly_days_by_building": an.groupby("building").anomaly.sum().astype(int).to_dict(),
        "lp_tau10_vs_t24_pct": {k: lp[f"{k}_vs_t24_pct"] for k in keys},
        "lp_tau10_vs_t26_pct": {k: lp[f"{k}_vs_t26_pct"] for k in keys},
        "lp_tau10_comfort_violation_Kh": lp["comfort_violation_Kh"],
        "top_shap_features_office": imp.head(5).round(2).to_dict(),
    }
    with open(RESULTS / "summary.json", "w") as fh:
        json.dump(summary, fh, indent=1, default=float)
    print(json.dumps(summary, indent=1, default=float))


if __name__ == "__main__":
    main()

#!/usr/bin/env bash
# Download the three BDG2 files this project uses (~195 MB total) into data/raw/.
# Source: Building Data Genome 2 (Miller et al., 2020), https://github.com/buds-lab/building-data-genome-project-2
set -euo pipefail
cd "$(dirname "$0")/.."
mkdir -p data/raw
BASE=https://media.githubusercontent.com/media/buds-lab/building-data-genome-project-2/master/data
curl -L -o data/raw/electricity_cleaned.csv "$BASE/meters/cleaned/electricity_cleaned.csv"
curl -L -o data/raw/weather.csv            "$BASE/weather/weather.csv"
curl -L -o data/raw/metadata.csv           "$BASE/metadata/metadata.csv"
echo "done: $(ls data/raw)"

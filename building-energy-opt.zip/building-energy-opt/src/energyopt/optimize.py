"""Day-ahead HVAC pre-cooling schedule on a 1R1C thermal model, solved as a linear program.

Zone model (hourly, exact discretisation of C dT/dt = (Tout - T)/R + G - Q):
    T[k+1] = a T[k] + (1 - a) (Tout[k] + R (G[k] - Q[k])),   a = exp(-dt / (R C))
    T  : zone air temperature (degC)      Q : cooling delivered (kW thermal)
    G  : internal + solar gains (kW th)   R : 1/UA (K/kW)    C : thermal capacitance (kWh/K)
Electric cooling power = Q / COP(Tout), with COP falling as outdoor temperature rises.

How the parameters are set (grey-box, from the building's own meter data):
  * UA comes from the 3P change-point slope: b1 (kW_e/K) x reference COP.
  * Mean gains are fixed by the balance point: steady state with T = setpoint gives
    G_mean = UA (T_set - Tb). Their hourly shape follows the building's non-cooling load.
  * The time constant tau = RC is NOT identifiable without indoor temperature data.
    It is assumed (10 h for a medium-mass office) and swept in a sensitivity study.
"""
from dataclasses import dataclass

import cvxpy as cp
import numpy as np
import pandas as pd


@dataclass
class Zone:
    UA: float          # kW_th / K
    tau_h: float       # R*C time constant, hours
    Q_max: float       # kW_th cooling capacity
    cop_ref: float = 3.0
    cop_slope: float = 0.025  # fractional COP drop per K above 35 degC

    @property
    def R(self):
        return 1.0 / self.UA

    @property
    def a(self):
        return float(np.exp(-1.0 / self.tau_h))

    def cop(self, tout):
        return np.clip(self.cop_ref * (1 - self.cop_slope * (np.asarray(tout) - 35.0)), 2.0, 5.0)

    def step(self, T, tout, G, Q):
        return self.a * T + (1 - self.a) * (tout + self.R * (G - Q))

    def q_for_target(self, T, tout, G, T_target):
        """Cooling needed so that the next-hour temperature equals T_target."""
        return G + (tout - (T_target - self.a * T) / (1 - self.a)) / self.R


@dataclass
class Tariff:
    """Illustrative summer time-of-use tariff (shape typical of US Southwest commercial rates)."""
    on_peak: float = 0.20          # $/kWh, weekdays 14:00-20:00
    off_peak: float = 0.07         # $/kWh
    demand: float = 15.0           # $/kW-month on the monthly max on-peak demand
    peak_hours: tuple = (14, 20)

    def is_on_peak(self, ts: pd.DatetimeIndex) -> np.ndarray:
        h, wd = ts.hour, ts.dayofweek < 5
        return np.asarray(wd & (h >= self.peak_hours[0]) & (h < self.peak_hours[1]))

    def price(self, ts: pd.DatetimeIndex) -> np.ndarray:
        return np.where(self.is_on_peak(ts), self.on_peak, self.off_peak)


def comfort_bounds(ts: pd.DatetimeIndex, occ_lo=23.0, occ_hi=26.0, unocc_lo=18.0, unocc_hi=29.0):
    """Bounds on end-of-hour zone temperature. Occupied = weekdays 07:00-19:00."""
    occ = np.asarray((ts.dayofweek < 5) & (ts.hour >= 7) & (ts.hour < 19))
    return np.where(occ, occ_lo, unocc_lo), np.where(occ, occ_hi, unocc_hi), occ


def plan_day(zone: Zone, tariff: Tariff, ts, tout, G, base_kw, T0, lo, hi) -> np.ndarray:
    """Minimise energy cost + daily share of the demand charge, subject to comfort bounds."""
    n = len(ts)
    cop = zone.cop(tout)
    price = tariff.price(ts)
    on = tariff.is_on_peak(ts)
    Q = cp.Variable(n, nonneg=True)
    T = cp.Variable(n + 1)
    s = cp.Variable(n, nonneg=True)  # comfort slack, heavily penalised
    P = base_kw + cp.multiply(1 / cop, Q)
    cons = [T[0] == T0, Q <= zone.Q_max,
            T[1:] == zone.a * T[:-1] + (1 - zone.a) * (tout + zone.R * (G - Q)),
            T[1:] >= lo - s, T[1:] <= hi + s]
    obj = price @ P + 1e3 * cp.sum(s) + 1e-4 * cp.sum(Q)
    if on.any():
        obj += (tariff.demand / 21.7) * cp.max(P[on])  # ~21.7 weekdays per month
    cp.Problem(cp.Minimize(obj), cons).solve(solver=cp.HIGHS)
    return np.asarray(Q.value).clip(0, zone.Q_max)


def execute(zone: Zone, tout, G_true, Q_cmd, T0, lo, hi):
    """Apply a cooling command to the 'true' zone with a supervisory safety clamp:
    if the command would push temperature outside the comfort band, cooling is
    adjusted to hold the band edge (within capacity), as a thermostat override would."""
    n = len(tout)
    T = np.empty(n + 1)
    T[0] = T0
    Q = np.empty(n)
    for k in range(n):
        q_min = zone.q_for_target(T[k], tout[k], G_true[k], hi[k])  # at least this much
        q_max = zone.q_for_target(T[k], tout[k], G_true[k], lo[k])  # at most this much
        q = min(max(Q_cmd[k], q_min), q_max)
        Q[k] = float(np.clip(q, 0, zone.Q_max))
        T[k + 1] = zone.step(T[k], tout[k], G_true[k], Q[k])
    return Q, T


def thermostat(zone: Zone, tout, G_true, T0, setpoint):
    """Reactive control: cool just enough to hold the setpoint (no anticipation)."""
    n = len(tout)
    T = np.empty(n + 1)
    T[0] = T0
    Q = np.empty(n)
    for k in range(n):
        Q[k] = float(np.clip(zone.q_for_target(T[k], tout[k], G_true[k], setpoint[k]), 0, zone.Q_max))
        T[k + 1] = zone.step(T[k], tout[k], G_true[k], Q[k])
    return Q, T


def summarise(name, ts, tout, Q, T, base_kw, zone: Zone, tariff: Tariff, occ, lo, hi) -> dict:
    ts = pd.DatetimeIndex(ts)
    cool_kw = Q / zone.cop(tout)
    P = base_kw + cool_kw
    price = tariff.price(ts)
    on = tariff.is_on_peak(ts)
    peaks = pd.Series(np.where(on, P, 0.0), index=ts).groupby(ts.to_period("M")).max()
    Tend = T[1:]
    viol = np.where(occ, np.clip(Tend - hi - 0.05, 0, None) + np.clip(lo - Tend - 0.05, 0, None), 0)
    return {
        "scenario": name,
        "hvac_kwh": float(cool_kw.sum()),
        "hvac_onpeak_kwh": float(cool_kw[on].sum()),
        "building_kwh": float(P.sum()),
        "energy_cost": float((price * P).sum()),
        "mean_monthly_onpeak_peak_kw": float(peaks.mean()),
        "demand_cost": float(tariff.demand * peaks.sum()),
        "total_cost": float((price * P).sum() + tariff.demand * peaks.sum()),
        "comfort_violation_Kh": float(viol.sum()),
        "occupied_T_mean": float(Tend[occ].mean()),
    }

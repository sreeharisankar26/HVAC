"""Load BDG2 electricity + weather for the selected buildings into one tidy frame."""
import pandas as pd

from .config import RAW, PROCESSED, SITE, BUILDINGS


def load_metadata() -> pd.DataFrame:
    return pd.read_csv(RAW / "metadata.csv").set_index("building_id")


def load_weather(site: str = SITE) -> pd.DataFrame:
    w = pd.read_csv(RAW / "weather.csv", parse_dates=["timestamp"])
    w = w[w.site_id == site].set_index("timestamp").sort_index()
    w = w[["airTemperature", "dewTemperature", "windSpeed", "cloudCoverage"]]
    full = pd.date_range(w.index.min(), w.index.max(), freq="h")
    w = w.reindex(full)
    # short gaps only; cloud cover has long gaps so it is filled and kept as a weak feature
    cols = ["airTemperature", "dewTemperature", "windSpeed"]
    w[cols] = w[cols].interpolate(limit=6)
    w["cloudCoverage"] = w["cloudCoverage"].ffill().bfill()
    w.index.name = "timestamp"
    return w


def load_long(force: bool = False) -> pd.DataFrame:
    """Long frame: timestamp, building, load_kw, weather columns."""
    out = PROCESSED / "fox_selected.parquet"
    if out.exists() and not force:
        return pd.read_parquet(out)
    e = pd.read_csv(RAW / "electricity_cleaned.csv", parse_dates=["timestamp"],
                    index_col="timestamp", usecols=["timestamp", *BUILDINGS])
    w = load_weather()
    frames = []
    for b in BUILDINGS:
        s = e[b].astype(float)
        s[s <= 0] = float("nan")  # zero readings in BDG2 are meter outages
        df = w.join(s.rename("load_kw"), how="inner")
        df["building"] = b
        frames.append(df)
    long = pd.concat(frames).reset_index()
    long.to_parquet(out, index=False)
    return long

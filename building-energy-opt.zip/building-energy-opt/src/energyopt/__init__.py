"""Building energy analysis, forecasting and HVAC pre-cooling optimization on BDG2 data."""

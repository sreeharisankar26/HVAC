"""Exploratory analysis: change-point weather models and anomaly flagging."""
import numpy as np
import pandas as pd


def fit_3p_cooling(temp_daily: pd.Series, load_daily: pd.Series) -> dict:
    """3-parameter cooling change-point model (ASHRAE Inverse Modeling Toolkit form):

        load = b0 + b1 * max(T - Tb, 0)

    b0 = base load (kW), b1 = cooling slope (kW per degC), Tb = balance point (degC).
    The balance point is found by grid search; b0 and b1 by least squares.
    """
    d = pd.concat([temp_daily, load_daily], axis=1, keys=["T", "y"]).dropna()
    best = None
    for tb in np.arange(5.0, 30.01, 0.25):
        x = np.clip(d["T"] - tb, 0, None)
        X = np.column_stack([np.ones(len(x)), x])
        coef, *_ = np.linalg.lstsq(X, d["y"].to_numpy(), rcond=None)
        resid = d["y"].to_numpy() - X @ coef
        sse = float(resid @ resid)
        if coef[1] > 0 and (best is None or sse < best["sse"]):
            best = {"b0": float(coef[0]), "b1": float(coef[1]), "Tb": float(tb), "sse": sse}
    sst = float(((d["y"] - d["y"].mean()) ** 2).sum())
    best["r2"] = 1 - best["sse"] / sst
    best["cvrmse"] = 100 * np.sqrt(best["sse"] / (len(d) - 3)) / d["y"].mean()
    cooling = best["b1"] * np.clip(d["T"] - best["Tb"], 0, None)
    best["weather_share"] = float(cooling.sum() / d["y"].sum())
    best["n_days"] = int(len(d))
    return best


def flag_anomalous_days(ts: pd.Series, y: pd.Series, yhat: pd.Series, k: float = 3.5) -> pd.DataFrame:
    """Flag days whose actual energy sits far above the model's expected energy.

    Daily residual = sum(actual - predicted). A day is flagged when its residual
    is more than k robust standard deviations (1.4826 * MAD) above the median.
    Only over-consumption is flagged, since that is the waste a facility team acts on.
    """
    df = pd.DataFrame({"ts": ts.values, "y": y.values, "yhat": yhat.values})
    day = df.groupby(df["ts"].dt.floor("D")).agg(
        actual_kwh=("y", "sum"), expected_kwh=("yhat", "sum"), n=("y", "size"))
    day = day[day["n"] >= 20].copy()
    day["resid_kwh"] = day["actual_kwh"] - day["expected_kwh"]
    med = day["resid_kwh"].median()
    mad = 1.4826 * (day["resid_kwh"] - med).abs().median()
    day["robust_z"] = (day["resid_kwh"] - med) / mad
    day["anomaly"] = day["robust_z"] > k
    return day

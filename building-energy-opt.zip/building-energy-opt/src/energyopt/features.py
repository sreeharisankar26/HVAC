"""Feature engineering for day-ahead hourly load forecasting.

Forecast setup: forecasts for every hour of day D are issued at the end of day D-1.
So load features may only use readings up to 23:00 of D-1:
  - lag_24h  : same hour yesterday   (always <= D-1 23:00)
  - lag_168h : same hour last week
  - prevday_mean : mean load over all of D-1
Weather features use observed weather for day D, standing in for a perfect
day-ahead weather forecast. Real forecasts would add some error.
"""
import holidays
import numpy as np
import pandas as pd

WEATHER = ["airTemperature", "dewTemperature", "windSpeed", "cloudCoverage"]


def add_calendar(df: pd.DataFrame) -> pd.DataFrame:
    ts = df["timestamp"]
    us_hol = holidays.US(years=[2016, 2017])
    df["hour"] = ts.dt.hour
    df["dow"] = ts.dt.dayofweek
    df["month"] = ts.dt.month
    df["is_weekend"] = (df["dow"] >= 5).astype(int)
    df["is_holiday"] = ts.dt.date.map(lambda d: d in us_hol).astype(int)
    doy = ts.dt.dayofyear
    df["doy_sin"] = np.sin(2 * np.pi * doy / 365.25)
    df["doy_cos"] = np.cos(2 * np.pi * doy / 365.25)
    return df


def build_features(g: pd.DataFrame) -> pd.DataFrame:
    """g: one building, hourly, columns timestamp, building, load_kw, weather."""
    g = g.sort_values("timestamp").set_index("timestamp").asfreq("h")
    g["building"] = g["building"].ffill().bfill()
    g = g.reset_index()
    g = add_calendar(g)
    y = g["load_kw"]
    g["lag_24h"] = y.shift(24)
    g["lag_168h"] = y.shift(168)
    daily = g.set_index("timestamp")["load_kw"].resample("D").mean()
    g["prevday_mean"] = g["timestamp"].dt.floor("D").map(daily.shift(1))
    t = g["airTemperature"]
    g["temp_roll3h"] = t.rolling(3, min_periods=1).mean()
    g["temp_roll24h"] = t.rolling(24, min_periods=1).mean()
    g["temp_daymax"] = g.groupby(g["timestamp"].dt.floor("D"))["airTemperature"].transform("max")
    return g


FEATURES = [
    "hour", "dow", "month", "is_weekend", "is_holiday", "doy_sin", "doy_cos",
    *WEATHER, "temp_roll3h", "temp_roll24h", "temp_daymax",
    "lag_24h", "lag_168h", "prevday_mean",
]

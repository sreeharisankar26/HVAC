"""Day-ahead hourly load forecasting: two baselines and a tuned XGBoost model."""
import numpy as np
import optuna
import pandas as pd
import xgboost as xgb
from sklearn.linear_model import Ridge

from .config import SEED, TRAIN_END, VAL_START
from .features import FEATURES
from .metrics import cvrmse

optuna.logging.set_verbosity(optuna.logging.WARNING)


# ---------- baselines ----------
def naive_seasonal(df: pd.DataFrame) -> np.ndarray:
    """Same hour last week."""
    return df["lag_168h"].to_numpy()


def _towt_design(df: pd.DataFrame) -> np.ndarray:
    """Time-of-week-and-temperature (TOWT) style regression, a standard M&V baseline:
    hour-of-week indicators + piecewise-linear temperature terms, with separate
    temperature slopes for occupied (weekday 7-19) and unoccupied hours."""
    how = (df["dow"] * 24 + df["hour"]).to_numpy()
    H = np.zeros((len(df), 168))
    H[np.arange(len(df)), how] = 1.0
    T = df["airTemperature"].to_numpy()
    segs = np.column_stack([np.clip(T - k, 0, None) for k in (10, 20, 25, 30, 35)])
    occ = ((df["dow"] < 5) & df["hour"].between(7, 19)).to_numpy().astype(float)
    return np.hstack([H, segs, segs * occ[:, None]])


def towt_fit_predict(train: pd.DataFrame, test: pd.DataFrame) -> np.ndarray:
    m = Ridge(alpha=1.0).fit(_towt_design(train), train["load_kw"])
    return m.predict(_towt_design(test))


# ---------- XGBoost ----------
def _xgb_params(trial: optuna.Trial) -> dict:
    return {
        "max_depth": trial.suggest_int("max_depth", 3, 9),
        "learning_rate": trial.suggest_float("learning_rate", 0.01, 0.2, log=True),
        "subsample": trial.suggest_float("subsample", 0.6, 1.0),
        "colsample_bytree": trial.suggest_float("colsample_bytree", 0.5, 1.0),
        "min_child_weight": trial.suggest_float("min_child_weight", 1, 30, log=True),
        "reg_lambda": trial.suggest_float("reg_lambda", 1e-3, 10, log=True),
        "gamma": trial.suggest_float("gamma", 1e-4, 5, log=True),
    }


def tune_xgb(train: pd.DataFrame, n_trials: int = 40) -> tuple[dict, int]:
    """Tune on a Jan-Sep 2016 -> Oct-Dec 2016 split. Returns best params and tree count."""
    fit = train[train["timestamp"] < VAL_START]
    val = train[train["timestamp"] >= VAL_START]

    def objective(trial):
        p = _xgb_params(trial)
        m = xgb.XGBRegressor(n_estimators=2000, early_stopping_rounds=100, random_state=SEED,
                             tree_method="hist", **p)
        m.fit(fit[FEATURES], fit["load_kw"], eval_set=[(val[FEATURES], val["load_kw"])], verbose=False)
        trial.set_user_attr("n_trees", m.best_iteration + 1)
        return cvrmse(val["load_kw"], m.predict(val[FEATURES]))

    study = optuna.create_study(direction="minimize", sampler=optuna.samplers.TPESampler(seed=SEED))
    study.optimize(objective, n_trials=n_trials)
    return study.best_params, study.best_trial.user_attrs["n_trees"]


def fit_xgb(train: pd.DataFrame, params: dict, n_trees: int) -> xgb.XGBRegressor:
    # refit on all of 2016 with ~10 % more trees since the training set is larger
    m = xgb.XGBRegressor(n_estimators=int(n_trees * 1.1), random_state=SEED, tree_method="hist", **params)
    m.fit(train[FEATURES], train["load_kw"])
    return m


def split(df: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame]:
    ok = df.dropna(subset=["load_kw", *FEATURES])
    return ok[ok["timestamp"] <= TRAIN_END], ok[ok["timestamp"] > TRAIN_END]

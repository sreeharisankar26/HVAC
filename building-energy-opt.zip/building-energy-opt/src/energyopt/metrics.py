"""Calibration metrics from ASHRAE Guideline 14.

Hourly calibration limits: CV(RMSE) <= 30 %, |NMBE| <= 10 %.
"""
import numpy as np

G14_HOURLY = {"cvrmse": 30.0, "nmbe": 10.0}


def cvrmse(y, yhat, p: int = 1) -> float:
    y, yhat = np.asarray(y, float), np.asarray(yhat, float)
    return 100 * np.sqrt(np.sum((y - yhat) ** 2) / (len(y) - p)) / y.mean()


def nmbe(y, yhat, p: int = 1) -> float:
    y, yhat = np.asarray(y, float), np.asarray(yhat, float)
    return 100 * np.sum(y - yhat) / ((len(y) - p) * y.mean())


def mape(y, yhat) -> float:
    y, yhat = np.asarray(y, float), np.asarray(yhat, float)
    return 100 * np.mean(np.abs(y - yhat) / y)


def all_metrics(y, yhat) -> dict:
    return {"cvrmse": cvrmse(y, yhat), "nmbe": nmbe(y, yhat), "mape": mape(y, yhat)}

from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
RAW = ROOT / "data" / "raw"
PROCESSED = ROOT / "data" / "processed"
RESULTS = ROOT / "results"
FIGURES = RESULTS / "figures"

SITE = "Fox"  # hot-arid site (US/Mountain timezone), cooling-dominated
BUILDINGS = [
    "Fox_office_Vicki",
    "Fox_education_Etta",
    "Fox_lodging_Frances",
    "Fox_assembly_Leeanne",
    "Fox_public_Denny",
]
# Building used for the optimization study: no separate chilled-water meter,
# so its cooling energy is on the electricity meter.
OPT_BUILDING = "Fox_office_Vicki"

TRAIN_END = "2016-12-31 23:00"   # train on 2016, test on 2017
VAL_START = "2016-10-01 00:00"   # last quarter of 2016 used for hyperparameter tuning
SEED = 42

for p in (PROCESSED, RESULTS, FIGURES):
    p.mkdir(parents=True, exist_ok=True)

# Building energy forecasting and HVAC pre-cooling optimization

Analysis, prediction and optimization of building electricity use on real meter data from the
[Building Data Genome 2](https://github.com/buds-lab/building-data-genome-project-2) dataset
(5 buildings at one hot-arid site, hourly, 2016–2017).

1. **Analysis**: change-point regression of load against outdoor temperature (base load, cooling slope,
   balance point, weather-driven share), weekly load profiles, and flagging of days with unexplained over-consumption.
2. **Prediction**: day-ahead hourly load forecasts with XGBoost tuned by Optuna, compared against two baselines
   and scored with the ASHRAE Guideline 14 calibration metrics. SHAP shows what drives the forecast.
3. **Optimization**: a 24-hour cooling schedule for an office zone under a time-of-use tariff, solved as a
   linear program on a 1R1C thermal model whose parameters come from the building's own meter data.

```
bash scripts/download_data.sh      # ~195 MB from the BDG2 repo
pip install -r requirements.txt
python scripts/run_all.py          # ~2 min; writes results/ and results/figures/
```

## Data

| Building | Use | Floor area (m²) | Mean load (kW) | Weather-driven share of 2016 energy |
|---|---|---|---|---|
| Fox_office_Vicki | Office | 6,581 | 146 | 19 % |
| Fox_education_Etta | Education | 4,498 | 195 | 14 % |
| Fox_lodging_Frances | Lodging | 10,341 | 100 | 11 % |
| Fox_assembly_Leeanne | Assembly | 1,933 | 19 | 36 % |
| Fox_public_Denny | Public services | 4,058 | 143 | 12 % |

All five buildings have >99 % complete electricity data. The site's summer highs reach 48 °C.
Train = 2016, test = 2017 (about 8,700 test hours per building). Hyperparameters were tuned on a
Jan–Sep → Oct–Dec 2016 split, so the 2017 test year is never seen during tuning.

## 1. Analysis

A 3-parameter cooling change-point model (`load = b0 + b1·max(T − Tb, 0)`) is fitted to daily means.
`Tb` is found by grid search, and `b0`, `b1` by least squares.

![change-point](results/figures/01_changepoint_models.png)

Balance points fall between 17 and 24 °C, with R² of 0.61–0.74. The assembly building is the most
weather-sensitive (36 % of its energy goes to cooling). The lodging building is the least (11 %).
Full table: `results/analysis_changepoint.csv`.

**Anomaly flagging.** The daily residual between actual and forecast energy is converted to a robust
z-score (median / MAD), and days above 3.5 are flagged. Only over-consumption is flagged. In 2017 this
flags 5 days for the public-services building and 4 for the assembly building. The other three have none.

![anomalies](results/figures/06_anomaly_days.png)

## 2. Day-ahead forecasting

Forecasts for all 24 hours of day D are issued at the end of day D-1, so load features only use readings
up to that point: the same hour yesterday, the same hour last week, and yesterday's mean. Calendar features
include US holidays. Weather features use observed weather in place of a weather forecast (see limitations).

Models compared:
- **Same hour last week**: a naive seasonal baseline.
- **TOWT regression**: time-of-week-and-temperature model, the standard baseline in measurement and
  verification (M&V) of energy savings. It uses 168 hour-of-week indicators plus piecewise temperature
  terms, with separate slopes for occupied and unoccupied hours.
- **XGBoost**: tuned with 40 Optuna (TPE) trials per building, with early stopping.

2017 test year, hourly:

| Building | Naive CV(RMSE) | TOWT CV(RMSE) | XGBoost CV(RMSE) | XGBoost NMBE |
|---|---|---|---|---|
| office Vicki | 9.9 % | 8.1 % | **6.4 %** | +0.4 % |
| education Etta | 18.5 % | 18.8 % | **12.3 %** | +0.5 % |
| lodging Frances | 10.8 % | 10.7 % | **8.7 %** | −0.9 % |
| assembly Leeanne | 29.1 % | 23.1 % | **20.5 %** | −1.0 % |
| public Denny | 11.9 % | 14.3 % | **8.9 %** | +1.4 % |
| mean | 16.0 % | 15.0 % | **11.4 %** | |

All five XGBoost models are within the ASHRAE Guideline 14 hourly limits (CV(RMSE) ≤ 30 %, |NMBE| ≤ 10 %).
Mean CV(RMSE) is 29 % lower than the naive baseline and 24 % lower than TOWT.

![cvrmse](results/figures/04_forecast_cvrmse.png)
![week](results/figures/03_forecast_week.png)
![shap](results/figures/05_shap_office.png)

For the office, the largest SHAP contributions come from last week's and yesterday's load at the same
hour, then hour of day, outdoor temperature and day of week.

## 3. Pre-cooling optimization (office Vicki, Jun–Sep 2017)

**Zone model.** The zone is modelled as one thermal resistance and one capacitance (1R1C):
`T[k+1] = a·T[k] + (1−a)·(Tout[k] + R·(G[k] − Q[k]))`, with `a = exp(−1 h / RC)`.
Electric cooling power is `Q / COP(Tout)`. COP is 3.0 at 35 °C and falls 2.5 % per K hotter.

The parameters are taken from the building's own data:
- `UA = 1/R` = change-point cooling slope × reference COP = **10.1 kW/K**.
- Mean internal gains are fixed by the balance point, `UA·(24 − Tb)`. Their hourly shape follows the
  building's non-cooling load.
- The planner uses the XGBoost forecast of that load. The simulated "true" zone uses the actual metered load.
- Cooling capacity is set to 1.3 × the design-day steady-state load (399 kW thermal).
- The time constant τ = RC **cannot be identified without indoor temperature data**. It is assumed to be
  10 h for a medium-mass office, and swept over 5, 10 and 20 h.

**Tariff (illustrative).** Weekdays 14:00–20:00 cost $0.20/kWh. All other hours cost $0.07/kWh.
There is also a $15/kW-month demand charge on the monthly on-peak maximum.

**Comfort.** Occupied hours (weekdays 07:00–19:00) must stay at 23–26 °C. Unoccupied hours allow 18–29 °C.

**Control strategies compared:**
- **Thermostat, fixed 24 °C**: typical operation, with overnight setback and a 2 h optimal start.
- **Thermostat, 26 °C**: holds the ceiling of the comfort band. This is the cheapest reactive strategy
  within the same comfort limits, so comparing against it isolates the value of shifting load.
- **LP pre-cooling**: each day a linear program (cvxpy + HiGHS) minimises energy cost plus the day's share
  of the demand charge, subject to the zone dynamics and comfort band. The plan is then applied to the
  "true" zone. If actual gains would push the zone out of the band, a thermostat-style override adds or
  removes cooling.
- **LP with perfect foresight**: the same, planned with the actual gains, giving an upper bound on what
  forecasting could achieve.

![hot day](results/figures/07_precooling_hot_day.png)

Summer 2017 results, τ = 10 h (whole-building bill = energy + demand charges):

| | vs fixed 24 °C | vs 26 °C thermostat |
|---|---|---|
| Total bill | −6.5 % | −4.2 % |
| Mean monthly on-peak demand | −13.8 % | −10.9 % |
| HVAC energy during on-peak hours | −29 % | −22 % |
| HVAC energy, total | −4.7 % | +1.3 % |
| Comfort violations, occupied hours | 0.07 K·h over 4 months | |

Planning with perfect foresight reduces the bill by a further 1.0 point, which is the cost of forecast error.

Sensitivity to the assumed time constant (on-peak demand change vs the 26 °C thermostat):
τ = 5 h → −6 %, 10 h → −11 %, 20 h → −21 %. Most of the benefit depends on the building's thermal mass,
so the absolute savings should be read as indicative. Full table: `results/optimization_results.csv`.

## Limitations

- Observed weather is used where an operational system would use a day-ahead weather forecast, so
  forecast errors here are optimistic.
- The optimization runs on a simulated 1R1C zone. There is no indoor-temperature data to calibrate the
  time constant, and no real building was controlled.
- The internal-gain profile is inferred by subtracting estimated cooling from metered load. Solar gains
  are folded into the balance point.
- The tariff is illustrative, not a specific utility's rate.
- BDG2 timestamps are treated as local time, and zero meter readings are treated as outages.

## Layout

```
src/energyopt/
  config.py     buildings, splits, paths
  data.py       load + join BDG2 electricity and weather
  features.py   day-ahead feature set (leakage-safe lags, calendar, weather)
  metrics.py    ASHRAE Guideline 14 CV(RMSE), NMBE
  analysis.py   3P change-point model, anomaly flagging
  forecast.py   naive, TOWT, XGBoost + Optuna
  optimize.py   1R1C zone, tariff, LP planner, thermostat, evaluation
scripts/run_all.py         full pipeline
scripts/download_data.sh   fetch data
results/                   metric tables, predictions, figures
```

Data: Miller, C., et al. (2020). The Building Data Genome 2 dataset. *Scientific Data* 7, 368.
